USE [Salesforcemgdb]
GO

/****** Object:  Table [dbo].[Opportunity]    Script Date: 11/15/2024 11:50:43 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Opportunity](
	[AccountId] [nvarchar](200) NULL,
	[ActivityMetricId] [nvarchar](200) NULL,
	[ActivityMetricRollupId] [nvarchar](200) NULL,
	[Amount] [decimal](18, 2) NULL,
	[CampaignId] [nvarchar](200) NULL,
	[CloseDate] [date] NULL,
	[ConnectionReceivedDate] [datetime] NULL,
	[ConnectionSentDate] [datetime] NULL,
	[ContactId] [nvarchar](200) NULL,
	[CreatedById] [nvarchar](200) NULL,
	[CreatedDate] [datetime] NULL,
	[Description] [nvarchar](255) NULL,
	[ExpectedRevenue] [decimal](18, 2) NULL,
	[Fiscal] [nvarchar](6) NULL,
	[FiscalQuarter] [int] NULL,
	[FiscalYear] [int] NULL,
	[ForecastCategory] [nvarchar](200) NULL,
	[ForecastCategoryName] [nvarchar](200) NULL,
	[HasOpenActivity] [bit] NULL,
	[HasOpportunityLineItem] [bit] NULL,
	[HasOverdueTask] [bit] NULL,
	[Id] [nvarchar](200) NULL,
	[IqScore] [nvarchar](200) NULL,
	[IsClosed] [bit] NULL,
	[IsDeleted] [bit] NULL,
	[IsPrivate] [bit] NULL,
	[IsWon] [bit] NULL,
	[LastActivityDate] [date] NULL,
	[LastAmountChangedHistoryId] [nvarchar](200) NULL,
	[LastCloseDateChangedHistoryId] [nvarchar](2000) NULL,
	[LastModifiedById] [nvarchar](200) NULL,
	[LastModifiedDate] [datetime] NULL,
	[LastReferencedDate] [datetime] NULL,
	[LastStageChangeDate] [datetime] NULL,
	[LastViewedDate] [datetime] NULL,
	[LeadSource] [nvarchar](255) NULL,
	[Name] [nvarchar](120) NULL,
	[NextStep] [nvarchar](255) NULL,
	[OwnerId] [nvarchar](200) NULL,
	[Pricebook2Id] [nvarchar](2000) NULL,
	[PrimaryPartnerAccountId] [nvarchar](200) NULL,
	[Probability] [decimal](3, 0) NULL,
	[PushCount] [int] NULL,
	[StageName] [nvarchar](200) NULL,
	[StageSortOrder] [int] NULL,
	[SystemModstamp] [datetime] NULL,
	[TotalOpportunityQuantity] [decimal](18, 2) NULL,
	[Type] [nvarchar](255) NULL,
	[CRMStatus] [nvarchar](10) NULL,
	[Record_Id] [nvarchar](40) NULL,
	[Error_Msg] [nvarchar](2000) NULL,
	[JobId] [nvarchar](3) NULL,
	[ProcessedDate] [datetime] NULL,
	[sequence_no] [int] IDENTITY(1,1) NOT NULL,
	[OppurtunityId_CRM] [nvarchar](50) NULL,
	[AccountID_SF] [nvarchar](50) NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Opportunity] ADD  CONSTRAINT [Opportunity_df_status]  DEFAULT ('R') FOR [CRMStatus]
GO

