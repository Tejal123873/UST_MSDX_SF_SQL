USE [Salesforcemgdb]
GO

/****** Object:  Table [dbo].[Account]    Script Date: 11/15/2024 11:47:29 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Account](
	[AccountNumber] [nvarchar](255) NULL,
	[AccountSource] [varchar](255) NULL,
	[ActivityMetricId] [nvarchar](200) NULL,
	[ActivityMetricRollupId] [nvarchar](200) NULL,
	[AnnualRevenue] [decimal](16, 3) NULL,
	[BillingAddress] [nvarchar](255) NULL,
	[BillingCity] [nvarchar](255) NULL,
	[BillingCountry] [nvarchar](255) NULL,
	[BillingGeocodeAccuracy] [nvarchar](255) NULL,
	[BillingLatitude] [decimal](18, 15) NULL,
	[BillingLongitude] [decimal](18, 15) NULL,
	[BillingPostalCode] [nvarchar](20) NULL,
	[BillingState] [nvarchar](80) NULL,
	[BillingStreet] [nvarchar](255) NULL,
	[CompareName] [nvarchar](80) NULL,
	[CompareSite] [nvarchar](80) NULL,
	[ConnectionReceivedDate] [datetime] NULL,
	[ConnectionSentDate] [datetime] NULL,
	[CreatedById] [nvarchar](200) NULL,
	[CreatedDate] [datetime] NULL,
	[Description] [nvarchar](255) NULL,
	[Fax] [nvarchar](50) NULL,
	[Id] [nvarchar](200) NULL,
	[Industry] [nvarchar](255) NULL,
	[IsDeleted] [bit] NULL,
	[Jigsaw] [nvarchar](20) NULL,
	[JigsawCompanyId] [nvarchar](20) NULL,
	[LastActivityDate] [datetime] NULL,
	[LastModifiedById] [nvarchar](200) NULL,
	[LastModifiedDate] [datetime] NULL,
	[LastReferencedDate] [datetime] NULL,
	[LastViewedDate] [datetime] NULL,
	[MasterRecordId] [nvarchar](200) NULL,
	[Name] [nvarchar](255) NULL,
	[NumberOfEmployees] [int] NULL,
	[OperatingHoursId] [nvarchar](200) NULL,
	[OwnerAlias] [nvarchar](30) NULL,
	[OwnerId] [nvarchar](200) NULL,
	[Ownership] [varchar](50) NULL,
	[ParentId] [nvarchar](200) NULL,
	[PersonActionCadenceAssigneeId] [nvarchar](200) NULL,
	[PersonActionCadenceId] [nvarchar](200) NULL,
	[PersonActionCadenceState] [nvarchar](200) NULL,
	[PersonScheduledResumeDateTime] [datetime] NULL,
	[Phone] [nvarchar](30) NULL,
	[PhotoUrl] [nvarchar](255) NULL,
	[Rating] [nvarchar](255) NULL,
	[ShippingAddress] [nvarchar](255) NULL,
	[ShippingCity] [nvarchar](40) NULL,
	[ShippingCountry] [nvarchar](80) NULL,
	[ShippingGeocodeAccuracy] [nvarchar](200) NULL,
	[ShippingLatitude] [decimal](18, 15) NULL,
	[ShippingLongitude] [decimal](18, 15) NULL,
	[ShippingPostalCode] [nvarchar](20) NULL,
	[ShippingState] [nvarchar](80) NULL,
	[ShippingStreet] [nvarchar](255) NULL,
	[Sic] [nvarchar](20) NULL,
	[SicDesc] [nvarchar](80) NULL,
	[Site] [nvarchar](80) NULL,
	[SystemModstamp] [datetime] NULL,
	[TickerSymbol] [nvarchar](20) NULL,
	[Tier] [nvarchar](20) NULL,
	[Type] [nvarchar](255) NULL,
	[Website] [nvarchar](255) NULL,
	[CRMStatus] [nvarchar](10) NULL,
	[Record_Id] [nvarchar](40) NULL,
	[Error_Msg] [nvarchar](2000) NULL,
	[JobId] [nvarchar](3) NULL,
	[ProcessedDate] [date] NULL,
	[AccountId] [nvarchar](100) NULL,
	[sequence_no] [int] IDENTITY(1,1) NOT NULL,
	[Target] [nvarchar](30) NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Account] ADD  CONSTRAINT [df_status]  DEFAULT ('R') FOR [CRMStatus]
GO

