USE [Salesforcemgdb]
GO

/****** Object:  Table [dbo].[Contact]    Script Date: 11/15/2024 11:49:55 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Contact](
	[AccountId] [nvarchar](200) NULL,
	[AccountName] [nvarchar](255) NULL,
	[ActionCadenceAssigneeId] [nvarchar](200) NULL,
	[ActionCadenceId] [nvarchar](200) NULL,
	[ActionCadenceState] [nvarchar](200) NULL,
	[ActivityMetricId] [nvarchar](200) NULL,
	[ActivityMetricRollupId] [nvarchar](200) NULL,
	[AssistantName] [nvarchar](255) NULL,
	[AssistantPhone] [int] NULL,
	[Birthdate] [datetime] NULL,
	[ConnectionReceivedDate] [datetime] NULL,
	[ConnectionSentDate] [datetime] NULL,
	[CreatedById] [nvarchar](200) NULL,
	[CreatedDate] [datetime] NULL,
	[Department] [nvarchar](255) NULL,
	[Description] [nvarchar](255) NULL,
	[DoNotCall] [bit] NULL,
	[Email] [nvarchar](255) NULL,
	[EmailBouncedDate] [datetime] NULL,
	[EmailBouncedReason] [nvarchar](255) NULL,
	[Fax] [nvarchar](200) NULL,
	[FirstCallDateTime] [datetime] NULL,
	[FirstEmailDateTime] [datetime] NULL,
	[FirstName] [nvarchar](40) NULL,
	[HasOptedOutOfEmail] [bit] NULL,
	[HasOptedOutOfFax] [bit] NULL,
	[HomePhone] [int] NULL,
	[Id] [nvarchar](200) NULL,
	[IndividualId] [nvarchar](200) NULL,
	[IsDeleted] [bit] NULL,
	[IsEmailBounced] [bit] NULL,
	[Jigsaw] [nvarchar](20) NULL,
	[JigsawContactId] [nvarchar](20) NULL,
	[LastActivityDate] [datetime] NULL,
	[LastCURequestDate] [datetime] NULL,
	[LastCUUpdateDate] [datetime] NULL,
	[LastModifiedById] [nvarchar](200) NULL,
	[LastModifiedDate] [datetime] NULL,
	[LastName] [nvarchar](80) NULL,
	[LastReferencedDate] [datetime] NULL,
	[LastViewedDate] [datetime] NULL,
	[LeadSource] [nvarchar](255) NULL,
	[MailingAddress] [nvarchar](255) NULL,
	[MailingCity] [nvarchar](40) NULL,
	[MailingCountry] [nvarchar](80) NULL,
	[MailingGeocodeAccuracy] [nvarchar](200) NULL,
	[MailingLatitude] [decimal](18, 15) NULL,
	[MailingLongitude] [decimal](18, 15) NULL,
	[MailingPostalCode] [nvarchar](20) NULL,
	[MailingState] [nvarchar](80) NULL,
	[MailingStreet] [nvarchar](255) NULL,
	[MasterRecordId] [nvarchar](200) NULL,
	[MobilePhone] [int] NULL,
	[Name] [nvarchar](121) NULL,
	[OtherAddress] [nvarchar](1000) NULL,
	[OtherCity] [nvarchar](40) NULL,
	[OtherCountry] [nvarchar](80) NULL,
	[OtherGeocodeAccuracy] [nvarchar](200) NULL,
	[OtherLatitude] [decimal](18, 15) NULL,
	[OtherLongitude] [decimal](18, 15) NULL,
	[OtherPhone] [int] NULL,
	[OtherPostalCode] [nvarchar](20) NULL,
	[OtherState] [nvarchar](200) NULL,
	[OtherStreet] [nvarchar](255) NULL,
	[OwnerId] [nvarchar](200) NULL,
	[Phone] [nvarchar](60) NULL,
	[PhotoUrl] [nvarchar](255) NULL,
	[ReportsToId] [nvarchar](200) NULL,
	[ReportsToName] [nvarchar](121) NULL,
	[Salutation] [nvarchar](200) NULL,
	[ScheduledResumeDateTime] [datetime] NULL,
	[SystemModstamp] [datetime] NULL,
	[Title] [nvarchar](128) NULL,
	[CRMStatus] [nvarchar](10) NULL,
	[Record_Id] [nvarchar](40) NULL,
	[Error_Msg] [nvarchar](2000) NULL,
	[ProcessedDate] [datetime] NULL,
	[JobId] [nvarchar](3) NULL,
	[sequence_no] [int] IDENTITY(1,1) NOT NULL,
	[ContactId] [nvarchar](200) NULL,
	[CRMAccountId] [nvarchar](200) NULL,
	[Target] [nvarchar](50) NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Contact] ADD  CONSTRAINT [Contact_df_status]  DEFAULT ('R') FOR [CRMStatus]
GO

ALTER TABLE [dbo].[Contact] ADD  DEFAULT ('account') FOR [Target]
GO

